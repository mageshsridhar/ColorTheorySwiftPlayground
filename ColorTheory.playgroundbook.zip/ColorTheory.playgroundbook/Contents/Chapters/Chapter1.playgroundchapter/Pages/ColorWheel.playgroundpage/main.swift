//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Color Wheel
//:
/*:
 ---
 The color wheel consists of all the colors we discussed till now. Sir Isaac Newton designed the first color wheel in 1666, and it introduced a whole new meaning to color harmonies and palettes.
 
 ![colors](Color-Wheel-2.gif width="600" height="600")
 Photo from: 99designs.com
 
 
 - Note: Run code once to complete this page.
 ---
  */
//: [Next Page](@next)

//#-hidden-code
import PlaygroundSupport
import SwiftUI
PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Let's go to the next page...")
//#-end-hidden-code
