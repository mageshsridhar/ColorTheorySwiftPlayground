//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Thank you for playing!
//:
/*:
 ---
 Amazing work! You can go to any level again using the page navigator to play it again. Thanks for playing this game, and hope you learned something new out of this.
 
 
 
 ![colors](colorsbackground.jpg)
 Photo from: 99designs.com
 
 
 - Note: Run code once to complete this page.
 ---
  */

//#-hidden-code
import PlaygroundSupport
import SwiftUI
PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Let's go to the next page...")
//#-end-hidden-code
