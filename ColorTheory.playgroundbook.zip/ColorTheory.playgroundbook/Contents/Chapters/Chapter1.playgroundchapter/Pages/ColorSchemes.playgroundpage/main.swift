//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Color Schemes
/*:
 ---
 Color schemes are logical combinations of colors on the color wheel. The purpose of a color scheme is to create an aesthetic feeling of style and appeal.
 We'll be going through three of the commonly used color schemes.
 
 
 - Complementary Colors
 - Analogous Colors
 - Triadic Colors
 
 
 ![colors](friends.jpeg)
 Photo from: Neomam studios
 
 
 - Note: Run code once to complete this page.
 ---
  */
//: [Next Page](@next)





