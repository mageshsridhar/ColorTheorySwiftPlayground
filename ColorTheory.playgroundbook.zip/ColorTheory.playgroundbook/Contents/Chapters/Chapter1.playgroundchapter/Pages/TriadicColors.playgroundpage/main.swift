//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Triadic Colors
/*:
 ---
 Triadic colors are evenly spaced around the color wheel and tend to be very bright and dynamic. Using a triadic color scheme in your design creates visual contrast and harmony simultaneously, making each item stand out while making the overall image pop.
 
 
 
 ![complementarycolors](triadic.png)
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in such a way they transition around the border of the triangle.
 ---
  */
//: [Next Page](@next)
