//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Color Theory
//:
/*:
 ---
 Hello there! Today we are going to learn color theory in a fun and interactive way. But why do you need to know the color theory?
 It explains the way you perceive colors and how colors form harmony when they mix or match together.
 Color Theory shows how colors communicate with each other, and it mainly helps in branding.
 The following lessons will teach you the concepts in Color Theory, and you will be a master of the perception of colors in no time.
 So, let's get started.
 
 
 ![colors](colors.jpg width="700")
 Photo by: Robert Katzki on Unsplash
 
 
 - Note: Run code once to complete this page.
 ---
  */
//: [Next Page](@next)

//#-hidden-code
import PlaygroundSupport
import SwiftUI
PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Let's go to the next page...")
//#-end-hidden-code
