//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Complementary Colors
/*:
 ---
 Complementary colors are opposites on the color wheel—red and green, for example. There’s a sharp contrast between the two colors so they can make imagery pop, but overusing them can get tiresome.
 
 
 
 ![complementarycolors](complementary.png)
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in the diagonals in such a way the colors transition from left to right in each row.
 ---
  */
//: [Next Page](@next)
