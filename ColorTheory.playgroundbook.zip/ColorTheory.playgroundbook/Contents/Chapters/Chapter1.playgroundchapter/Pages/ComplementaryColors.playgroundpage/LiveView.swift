import SwiftUI
import SpriteKit
import PlaygroundSupport
let skView = SKView(frame: .zero)
let gameScene = ComplementaryColors(size: UIScreen.main.bounds.size)
gameScene.scaleMode = .aspectFill
skView.presentScene(gameScene)
PlaygroundPage.current.liveView = skView
func hexStringToUIColor (hex:String) -> UIColor {
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    
    var rgbValue:UInt32 = 0
    Scanner(string: cString).scanHexInt32(&rgbValue)
    
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}


public class ComplementaryColors : SKScene{
    var selectedNode : SKNode?
    var initialPoint = CGPoint(x:0,y:0)
    var swapNode : SKNode?
    let firstColumn = ["#4e2b76", "#e95a28", "#f28923","#f7b92d","#e6433e" ] //red, purple, blue, green, yellow, orange
    let secondColumn = ["#bd0b48","#1f93a2","#e64452","#81b630","#a7cf69"]
    let thirdColumn = ["#97095b", "#a2156a","#65267e", "#28a970", "#71bf88"]
    let fourthColumn = ["#6a1665","#ce1847", "#714a9a", "#c13b88", "#4bb6a8"]
    let fifthColumn = ["#44b8c7", "#26408c","#1364a7", "#1d88b5", "#f6ee66"]
    var finalColors = ["#e6433e":0, "#e95a28":1, "#f28923":2,"#f7b92d":3, "#f6ee66":4,"#bd0b48":5, "#ce1847":6, "#e64452":7,"#81b630":8, "#a7cf69":9,"#97095b":10, "#a2156a":11,"#c13b88":12, "#28a970":13, "#71bf88":14,"#6a1665":15, "#65267e":16,"#714a9a":17, "#1f93a2":18, "#4bb6a8":19,"#4e2b76":20, "#26408c":21,"#1364a7":22, "#1d88b5":23, "#44b8c7":24]
    var winCheck = [CGFloat:Int]()
    var ypos = UIScreen.main.bounds.midY + UIScreen.main.bounds.height/2.5
    var order = [Int]()
    var positions = [CGPoint]()
    let heightofBlock = UIScreen.main.bounds.height/8
    var xpos = UIScreen.main.bounds.midX - UIScreen.main.bounds.height/4
    var touchCount = 0
    let firstClick = SKAction.playSoundFileNamed("click_002.wav",waitForCompletion: false)
    let secondClick = SKAction.playSoundFileNamed("click_003.wav",waitForCompletion: false)
    let levelEnded = SKAction.playSoundFileNamed("impactMining_002.wav",waitForCompletion: false)
    public override func didMove(to view: SKView) {
        xpos = xpos.rounded()
        ypos = ypos.rounded()
        self.backgroundColor = .black
        for i in 0...firstColumn.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.firstColumn[i]), size: CGSize(width: self.heightofBlock.rounded(), height: self.heightofBlock.rounded()))
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 18, height: 24))
            self.ypos = self.ypos - self.heightofBlock.rounded()
            block.name = "block"
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.firstColumn[i]]!)
            if i != 0 && i != firstColumn.count-1{
                block.name = "locked"
                lock.position = CGPoint(x: self.xpos, y: self.ypos)
                self.addChild(lock)
            }
        }
        xpos = xpos + heightofBlock.rounded()
        ypos = UIScreen.main.bounds.midY + UIScreen.main.bounds.height/2.5
        ypos = ypos.rounded()
        for i in 0...secondColumn.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.secondColumn[i]), size: CGSize(width: self.heightofBlock.rounded(), height: self.heightofBlock.rounded()))
            self.ypos = self.ypos - self.heightofBlock.rounded()
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 18, height: 24))
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            block.name = "block"
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.secondColumn[i]]!)
            if i != 1 && i != secondColumn.count-2{
                block.name = "locked"
                self.addChild(lock)
            }
        }
        xpos = xpos + heightofBlock.rounded()
        ypos = UIScreen.main.bounds.midY + UIScreen.main.bounds.height/2.5
        ypos = ypos.rounded()
        for i in 0...thirdColumn.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.thirdColumn[i]), size: CGSize(width: self.heightofBlock.rounded(), height: self.heightofBlock.rounded()))
            self.ypos = self.ypos - self.heightofBlock.rounded()
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 18, height: 24))
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            block.name = "block"
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.thirdColumn[i]]!)
            if i != 2 {
                block.name = "locked"
                self.addChild(lock)
            }
        }
        xpos = xpos + heightofBlock.rounded()
        ypos = UIScreen.main.bounds.midY + UIScreen.main.bounds.height/2.5
        ypos = ypos.rounded()
        for i in 0...fourthColumn.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.fourthColumn[i]), size: CGSize(width: self.heightofBlock.rounded(), height: self.heightofBlock.rounded()))
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 18, height: 24))
            self.ypos = self.ypos - self.heightofBlock.rounded()
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.fourthColumn[i]]!)
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            if i != 1 && i != fourthColumn.count-2{
                block.name = "locked"
                self.addChild(lock)
            }
        }
        xpos = xpos + heightofBlock.rounded()
        ypos = UIScreen.main.bounds.midY + UIScreen.main.bounds.height/2.5
        ypos = ypos.rounded()
        for i in 0...fifthColumn.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.fifthColumn[i]), size: CGSize(width: self.heightofBlock.rounded(), height: self.heightofBlock.rounded()))
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 18, height: 24))
            self.ypos = self.ypos - self.heightofBlock.rounded()
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.fifthColumn[i]]!)
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            if i != 0 && i != fifthColumn.count-1{
                block.name = "locked"
                self.addChild(lock)
            }
        }
        
    }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: self)
        print(point)
        let nodesFound = nodes(at: point)
        guard let node = nodesFound.last else { return }
        var temp = CGPoint(x:0,y:0)
        if node.name != "locked" && node.name != "image"{
            touchCount = touchCount+1
            node.yScale = 1.06
            node.xScale = 1.06
        }
        if nodesFound.count != 0 {
                if touchCount == 1{
                        if nodesFound.last!.name != "locked" {
                            run(firstClick)
                            self.selectedNode = nodesFound.last
                            print(self.selectedNode!.position)
                    }
                }
                else if touchCount == 2{
                    run(secondClick)
                    guard let node = self.selectedNode else { return }
                    self.swapNode = nodesFound.last
                    guard let endnode = swapNode else { return }
                    if node.name != "locked" && endnode.name != "locked" && node.name != "image" && endnode.name != "image"
                    {
                        temp = node.position
                        let swapTemp = order[positions.firstIndex(of: node.position)!]
                        order[positions.firstIndex(of: node.position)!] = order[positions.firstIndex(of: endnode.position)!]
                        let nodemoveAnimation = SKAction.move(to: endnode.position, duration: 0.15)
                        node.run(nodemoveAnimation)
                        order[positions.firstIndex(of: endnode.position)!] = swapTemp
                        let endnodemoveAnimation = SKAction.move(to: temp, duration: 0.15)
                        endnode.run(endnodemoveAnimation)
                        node.yScale = 1
                        endnode.yScale = 1
                        node.xScale = 1
                        endnode.xScale = 1
                        if order == order.sorted(){
                            run(levelEnded)
                            PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Let's go to the next page...")
                        }
                        touchCount = 0
                    }
                }
        }
    }
}

