import SwiftUI
import SpriteKit
import PlaygroundSupport
let skView = SKView(frame: .zero)
let gameScene = AnalogousColors(size: UIScreen.main.bounds.size)
gameScene.scaleMode = .aspectFill
skView.presentScene(gameScene)
PlaygroundPage.current.liveView = skView
func hexStringToUIColor (hex:String) -> UIColor {
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    
    var rgbValue:UInt32 = 0
    Scanner(string: cString).scanHexInt32(&rgbValue)
    
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}


public class AnalogousColors : SKScene{
    var selectedNode : SKNode?
    var initialPoint = CGPoint(x:0,y:0)
    var swapNode : SKNode?
    let firstRow = ["#f8e16c","#008a6f","#5a400e","#1f536f"]
    let secondRow = ["#8eb348","#52600e","#4ca05e","#005666","#008b8e","#233d4d"]
    let thirdRow = ["#178138","#007072","#6abf7d","#4c2719"]
    var finalColors = ["#f8e16c":0, "#6abf7d":1,"#008b8e":2,"#1f536f":3,"#8eb348":4, "#4ca05e":5,"#008a6f":6,"#007072":7,"#005666":8,"#233d4d":9,"#178138":10, "#52600e":11,"#5a400e":12,"#4c2719":13]
    var winCheck = [CGFloat:Int]()
    var xpos = UIScreen.main.bounds.midX - 10
    var ypos = UIScreen.main.bounds.midY + 150
    var order = [Int]()
    var positions = [CGPoint]()
    let widthofBlock = UIScreen.main.bounds.width/18
    var touchCount = 0
    let firstClick = SKAction.playSoundFileNamed("click_002.wav",waitForCompletion: false)
    let secondClick = SKAction.playSoundFileNamed("click_003.wav",waitForCompletion: false)
    let levelEnded = SKAction.playSoundFileNamed("impactMining_002.wav",waitForCompletion: false)
    public override func didMove(to view: SKView) {
        self.backgroundColor = .black
        var i = 0
        xpos = xpos - widthofBlock*2
        while i<=self.firstRow.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.firstRow[i]), size: CGSize(width: self.widthofBlock, height: self.widthofBlock))
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 14, height: 20))
            self.xpos = self.xpos + self.widthofBlock
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.firstRow[i]]!)
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            block.name = "block"
            if i == 0 || i==firstRow.count-1{
                block.name = "locked"
                lock.name = "locked"
                self.addChild(lock)
            }
            i = i+1
        }
        xpos = UIScreen.main.bounds.midX - 10 - widthofBlock*3
        ypos = ypos - widthofBlock
        i=0
        while i<=self.secondRow.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.secondRow[i]), size: CGSize(width: self.widthofBlock, height: self.widthofBlock))
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 14, height: 20))
            self.xpos = self.xpos + self.widthofBlock
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.secondRow[i]]!)
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            block.name = "block"
            if i == 0 || i==secondRow.count-1{
                block.name = "locked"
                self.addChild(lock)
            }
            i = i+1
        }
        xpos = UIScreen.main.bounds.midX - 10 - widthofBlock*2
        ypos = ypos - widthofBlock
        i=0
        while i<=self.thirdRow.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.thirdRow[i]), size: CGSize(width: self.widthofBlock, height: self.widthofBlock))
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 14, height: 20))
            self.xpos = self.xpos + self.widthofBlock
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            self.positions.append(block.position)
            self.order.append(self.finalColors[self.thirdRow[i]]!)
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            block.name = "block"
            if i == 0 || i==thirdRow.count-1{
                block.name = "locked"
                self.addChild(lock)
            }
            i = i+1
        }
        
    }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: self)
        print(point)
        let nodesFound = nodes(at: point)
        guard let node = nodesFound.last else { return }
        var temp = CGPoint(x:0,y:0)
        if node.name != "locked" && node.name != "image"{
            touchCount = touchCount+1
            node.yScale = 1.06
            node.xScale = 1.06
        }
        if nodesFound.count != 0 {
                if touchCount == 1{
                        if nodesFound.last!.name != "locked" {
                            run(self.firstClick)
                            self.selectedNode = nodesFound.last
                            print(self.selectedNode!.position)
                    }
                }
                else if touchCount == 2{
                    run(self.secondClick)
                    guard let node = self.selectedNode else { return }
                    self.swapNode = nodesFound.last
                    guard let endnode = swapNode else { return }
                    if node.name != "locked" && endnode.name != "locked" && node.name != "image" && endnode.name != "image"
                    {
                        temp = node.position
                        let swapTemp = order[positions.firstIndex(of: node.position)!]
                        order[positions.firstIndex(of: node.position)!] = order[positions.firstIndex(of: endnode.position)!]
                        let nodemoveAnimation = SKAction.move(to: endnode.position, duration: 0.15)
                        node.run(nodemoveAnimation)
                        order[positions.firstIndex(of: endnode.position)!] = swapTemp
                        let endnodemoveAnimation = SKAction.move(to: temp, duration: 0.15)
                        endnode.run(endnodemoveAnimation)
                        node.yScale = 1
                        endnode.yScale = 1
                        node.xScale = 1
                        endnode.xScale = 1
                        if order == order.sorted(){
                            run(self.levelEnded)
                            PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Let's go to the next page...")
                        }
                        touchCount = 0
                    }
                }
        }
    }
}

