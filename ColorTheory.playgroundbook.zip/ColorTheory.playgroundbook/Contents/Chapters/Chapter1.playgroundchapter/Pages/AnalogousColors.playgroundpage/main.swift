//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Analogous Colors
/*:
 ---
 Analogous colors are colors adjacent to one another on the color wheel—for example, red, orange, and yellow. When creating an analogous color scheme, one color will dominate, one will support, and another will accent.
 
 
 ![analogouscolors](analogous.png)
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in such a way they transition from left to right in each row.
 ---
  */
//: [Next Page](@next)
