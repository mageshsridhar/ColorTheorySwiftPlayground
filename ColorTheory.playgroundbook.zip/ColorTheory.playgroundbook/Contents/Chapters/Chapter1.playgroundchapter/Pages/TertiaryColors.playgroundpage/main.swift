//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Tertiary Colors
/*:
 ---
 Tertiary Colors were made by mixing one primary and one secondary color that are adjacent to each other.
 
 
 💜 Purple + ❤️ Red = Red-Purple (Magenta)
 
 
 💙 Blue + 💜 Purple = Blue-Purple (Violet)
 
 
 💚 Green + 💙 Blue = Blue-Green (Teal)
 
 
 💛 Yellow + 💚 Green = Yellow-Green (Chartreuse)


 
 🧡 Orange + 💛 Yellow = Yellow-Orange (Amber)
 

 
 ❤️ Red + 🧡 Orange = Red-Orange (Vermillion)

 
 
 ![tertiarycolors](tertiary.jpg)
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in such a way that the color in the middle is a mix of left and right colors in each row.
 ---
  */
//: [Next Page](@next)


