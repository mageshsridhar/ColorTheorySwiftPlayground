//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Cool Colors
/*:
 ---
 Another half of the color wheel represents the cool colors. They are associated with calmness, serenity, and peace. The temperature of colors in your design plays a vital role in your message.
 
 ![coolcolors](coolcolorshalf.png height="700")
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in such a way they transition from left to right.
 ---
  */
//: [Next Page](@next)
