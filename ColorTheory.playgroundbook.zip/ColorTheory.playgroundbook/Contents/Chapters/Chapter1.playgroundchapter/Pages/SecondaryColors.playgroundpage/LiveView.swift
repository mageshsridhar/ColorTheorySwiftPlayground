import SwiftUI
import SpriteKit
import PlaygroundSupport
let skView = SKView(frame: .zero)
let gameScene = SecondaryLevel(size: UIScreen.main.bounds.size)
gameScene.scaleMode = .aspectFill
skView.presentScene(gameScene)
PlaygroundPage.current.liveView = skView
func hexStringToUIColor (hex:String) -> UIColor {
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    
    var rgbValue:UInt32 = 0
    Scanner(string: cString).scanHexInt32(&rgbValue)
    
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}


public class SecondaryLevel : SKScene{
    var selectedNode : SKNode?
    var initialPoint = CGPoint(x:0,y:0)
    var swapNode : SKNode?
    let randomColors = ["#8a1c7c","#938d00","#5d891a", "#dd3560", "#fe8134","#f4594b","#b91d71","#c98a00","#178138"]
    var finalColors = ["#8a1c7c": 0,"#b91d71": 1,"#dd3560" : 2, "#f4594b" : 3, "#fe8134" : 4,"#c98a00" : 5,"#938d00" : 6,"#5d891a" : 7, "#178138": 8]
    var winCheck = [CGFloat:Int]()
    var xpos = UIScreen.main.bounds.midX
    var ypos = UIScreen.main.bounds.midY
    var order = [Int]()
    var positions = [CGFloat]()
    let widthofBlock = UIScreen.main.bounds.width/22
    var touchCount = 0
    let firstClick = SKAction.playSoundFileNamed("click_002.wav",waitForCompletion: false)
    let secondClick = SKAction.playSoundFileNamed("click_003.wav",waitForCompletion: false)
    let levelEnded = SKAction.playSoundFileNamed("impactMining_002.wav",waitForCompletion: false)
    public override func didMove(to view: SKView) {
        self.backgroundColor = .black
        var i = 0
        xpos = xpos - widthofBlock*4
        xpos = xpos.rounded()
        while i<=self.randomColors.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.randomColors[i]), size: CGSize(width: self.widthofBlock.rounded(), height: UIScreen.main.bounds.height/2.5))
            self.positions.append(self.xpos)
            self.order.append(self.finalColors[self.randomColors[i]]!)
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 14, height: 20))
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            block.name = "block"
            if i % 4 == 0{
                block.name = "locked"
                self.addChild(lock)
            }
            self.xpos = self.xpos + self.widthofBlock.rounded()
            i = i+1
        }
        
    }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: self)
        print(point)
        let nodesFound = nodes(at: point)
        guard let node = nodesFound.last else { return }
        var temp = CGPoint(x:0,y:0)
        if node.name != "locked"{
            touchCount = touchCount+1
            node.yScale = 1.06
        }
        if nodesFound.count != 0 {
                if touchCount == 1{
                    if nodesFound.last!.name != "locked" {
                        run(firstClick)
                    self.selectedNode = nodesFound.last
                    print(self.selectedNode!.position)
                    }
                }
                else if touchCount == 2{
                    guard let node = self.selectedNode else { return }
                    self.swapNode = nodesFound.last
                    guard let endnode = swapNode else { return }
                    print(node.position)
                    print(endnode.position)
                    if node.name != "locked" && endnode.name != "locked"{
                        run(secondClick)
                        temp = node.position
                        let swapTemp = order[positions.firstIndex(of: node.position.x)!]
                        order[positions.firstIndex(of: node.position.x)!] = order[positions.firstIndex(of: endnode.position.x)!]
                        let nodemoveAnimation = SKAction.moveTo(x: endnode.position.x, duration: 0.15)
                        node.run(nodemoveAnimation)
                        order[positions.firstIndex(of: endnode.position.x)!] = swapTemp
                        let endnodemoveAnimation = SKAction.moveTo(x: temp.x, duration: 0.15)
                        endnode.run(endnodemoveAnimation)
                        node.yScale = 1
                        endnode.yScale = 1
                        if order == order.sorted(){
                            run(levelEnded)
                            PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Let's go to the next page...")
                            
                        }
                        touchCount = 0
                    }
                }
        }
    }
}

