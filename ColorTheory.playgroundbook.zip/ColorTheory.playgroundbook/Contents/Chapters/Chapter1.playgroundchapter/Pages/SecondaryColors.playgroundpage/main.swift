//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Secondary Colors
/*:
 ---
 Secondary colors were obtained by mixing two of the primary colors.
 
 
 ❤️ Red + 💛 Yellow = 🧡 Orange

 
 💛 Yellow + 💙 Blue = 💚 Green
 
 
 ❤️ Red + 💙 Blue = 💜 Purple
 
 
 ![secondarycolors](secondary.jpg)
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in such a way they transition from left to right.
 ---
  */
//: [Next Page](@next)
