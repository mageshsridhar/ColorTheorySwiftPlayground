//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Warm Colors
/*:
 ---
 Warm colors are generally associated with energy, brightness, and action. Draw a line through the center of the color wheel, and you'll separate the warm colors.
 
 
 ![warmcolors](warmcolorshalf.png)
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in such a way they transition from left to right.
 ---
  */
//: [Next Page](@next)


