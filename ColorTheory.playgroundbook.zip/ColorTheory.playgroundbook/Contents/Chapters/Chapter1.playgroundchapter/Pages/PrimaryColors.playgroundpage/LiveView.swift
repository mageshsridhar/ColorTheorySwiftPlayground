import SwiftUI
import SpriteKit
import PlaygroundSupport
let skView = SKView(frame: .zero)
let gameScene = PrimaryLevel(size: UIScreen.main.bounds.size)
gameScene.scaleMode = .aspectFill
skView.presentScene(gameScene)
PlaygroundPage.current.liveView = skView

func hexStringToUIColor (hex:String) -> UIColor {
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    
    var rgbValue:UInt32 = 0
    Scanner(string: cString).scanHexInt32(&rgbValue)
    
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}

public class PrimaryLevel : SKScene{
    var selectedNode : SKNode?
    var initialPoint = CGPoint(x:0,y:0)
    var swapNode : SKNode?
    let randomColors = ["#e42535","#85d27e","#f69133", "#0090b1", "#f8e16c","#f8ba49","#00b5a2","#f0632e","#336699"]
    var finalColors = ["#e42535": 0,"#f0632e": 1,"#f69133" : 2, "#f8ba49" : 3, "#f8e16c" : 4,"#85d27e" : 5,"#00b5a2" : 6,"#0090b1" : 7, "#336699": 8]
    var winCheck = [CGFloat:Int]()
    var xpos = UIScreen.main.bounds.midX
    var ypos = UIScreen.main.bounds.maxY - 60
    var order = [Int]()
    var positions = [CGFloat]()
    let heightofBlock = UIScreen.main.bounds.height/11
    var touchCount = 0
    let firstClick = SKAction.playSoundFileNamed("click_002.wav",waitForCompletion: false)
    let secondClick = SKAction.playSoundFileNamed("click_003.wav",waitForCompletion: false)
    let levelEnded = SKAction.playSoundFileNamed("impactMining_002.wav",waitForCompletion: false)
    public override func didMove(to view: SKView) {
        self.backgroundColor = .black
        var i = 0
        while i<=self.randomColors.count-1{
            let block = SKSpriteNode(color: hexStringToUIColor(hex: self.randomColors[i]), size: CGSize(width: UIScreen.main.bounds.width/2.5, height: self.heightofBlock.rounded()))
            let lock = SKSpriteNode(texture: SKTexture(image: UIImage.init(systemName: "lock.fill")!),size: CGSize(width: 14, height: 20))
            self.ypos = self.ypos - self.heightofBlock.rounded()
            self.positions.append(self.ypos)
            self.order.append(self.finalColors[self.randomColors[i]]!)
            block.position = CGPoint(x: self.xpos, y: self.ypos)
            self.addChild(block)
            lock.position = CGPoint(x: self.xpos, y: self.ypos)
            block.name = "block"
            if i % 4 == 0{
                block.name = "locked"
                self.addChild(lock)
            }
            i = i+1
        }
        
    }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: self)
        print(point)
        let nodesFound = nodes(at: point)
        guard let node = nodesFound.last else { return }
        var temp = CGPoint(x:0,y:0)
        if node.name != "locked"{
            
            touchCount = touchCount+1
            node.xScale = 1.06
        }
        if nodesFound.count != 0 {
                if touchCount == 1{
                    if nodesFound.last!.name != "locked" {
                    run(self.firstClick)
                    self.selectedNode = nodesFound.last
                    }
                }
                else if touchCount == 2{
                    run(self.secondClick)
                    guard let node = self.selectedNode else { return }
                    self.swapNode = nodesFound.last
                    guard let endnode = swapNode else { return }
                    print(node.position)
                    print(endnode.position)
                    if node.name != "locked" && endnode.name != "locked"{
                        temp = node.position
                        let swapTemp = order[positions.firstIndex(of: node.position.y)!]
                        order[positions.firstIndex(of: node.position.y)!] = order[positions.firstIndex(of: endnode.position.y)!]
                        let nodemoveAnimation = SKAction.moveTo(y: endnode.position.y, duration: 0.15)
                        node.run(nodemoveAnimation)
                        order[positions.firstIndex(of: endnode.position.y)!] = swapTemp
                        let endnodemoveAnimation = SKAction.moveTo(y: temp.y, duration: 0.15)
                        endnode.run(endnodemoveAnimation)
                        node.xScale = 1
                        endnode.xScale = 1
                        if order == order.sorted(){
                            run(levelEnded)
                            PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Let's go to the next page...")
                        }
                        touchCount = 0
                    }
                }
        }
    }
}
