//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: # Primary Colors
/*:
 ---
 Primary colors are a set of colors that can be used to make a range of colors. They are red, yellow and blue.
 
 
 ![primarycolors](primary.png)
 Photo from: 99designs.com
 
 - Callout(How to Play): Tap on one unlocked color and tap on another unlocked color to swap their positions.
 
 
 
 + Callout(Objective): Rearrange the colors in such a way they transition from top to bottom.
 ---
  */
//: [Next Page](@next)
